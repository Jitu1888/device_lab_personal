# Audio Test App

A React web application for manual testers to upload, play, and stop audio clips on Android devices in the Device Lab.

## Features

- 📱 **Platform Tabs**: Separate tabs for Android and iOS testing (iOS coming soon)
- 🎵 **Upload MP3 Files**: Upload audio files to the backend server
- 📱 **Device Selection**: Automatically loads and displays available devices in a dropdown
- ▶️ **Play Audio**: Play audio files on specific Android devices via ADB
- ⏹️ **Stop Playback**: Stop audio playback on devices
- 🔧 **Configurable**: Set custom backend server URL
- 🔄 **Refresh Devices**: Manually refresh the device list
- 🎨 **Beautiful UI**: Modern, responsive design with gradient backgrounds

### Android Testing (Available Now)
- Full audio testing functionality for Android devices
- Upload, play, and stop audio files
- Device selection from connected Android devices

### iOS Testing (Coming Soon)
- iOS audio testing functionality is planned for future release

## Prerequisites

- Node.js 14 or higher
- npm or yarn
- Backend server running (Spring Boot application with audio endpoints)

## Installation

1. Navigate to the project directory:
```bash
cd audio-test-app
```

2. Install dependencies:
```bash
npm install
```

## Running the Application

Start the development server:
```bash
npm start
```

The application will open in your browser at [http://localhost:3000](http://localhost:3000)

## Usage

### 1. Select Platform
- Choose between **Android** 🤖 or **iOS** 🍎 tabs
- Android functionality is fully available
- iOS is coming soon

### 2. Configure Server URL (Android Tab)
- Enter your backend server URL (default: `http://localhost:8080/appium`)
- Click "Update Server URL"

### 3. Select Device (Android Tab)
- Select a device from the dropdown menu
- Devices are automatically loaded from the backend
- Click "Refresh Devices" to reload the list if needed

### 4. Select Audio File (Android Tab)
- Click "Select MP3 File"
- Choose an MP3 audio file from your computer

### 5. Upload Audio (Android Tab)
- Click "Upload to Server" to upload the file to the backend
- The file will be stored in the `audio` folder on the server

### 6. Play Audio (Android Tab)
- Click "Play on Device" to play the audio on the specified device
- The app will:
  - Push the audio file to `/sdcard/Download/` on the device
  - Launch the default media player to play the audio

### 7. Stop Playback (Android Tab)
- Click "Stop Playback" to stop the audio
- This sends a back button command to close the media player

## Backend API Endpoints

The app connects to these backend endpoints:

- `GET /findAllDevices` - Get list of all available devices
- `POST /appium/uploadAudio` - Upload MP3 file
- `POST /appium/playAudio/{udid}` - Play audio on device
- `POST /appium/stopAudio/{udid}` - Stop audio playback

## Building for Production

Create a production build:
```bash
npm run build
```

The build folder will contain the optimized production files.

## Project Structure

```
audio-test-app/
├── public/
│   └── index.html
├── src/
│   ├── services/
│   │   └── audioTestAPI.js    # API service for backend communication
│   ├── App.js                  # Main application component
│   ├── App.css                 # Application styles
│   ├── index.js                # Entry point
│   └── index.css               # Global styles
├── package.json
└── README.md
```

## Troubleshooting

### CORS Issues
If you encounter CORS errors, ensure your backend has proper CORS configuration:

```java
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/appium")
public class AppiumController {
    // ...
}
```

### Network Configuration
When testing on a real device or remote server:
1. Find your server's IP address: `ifconfig` (Mac/Linux) or `ipconfig` (Windows)
2. Update the server URL to: `http://<server-ip>:8080/appium`
3. Ensure both your computer and test devices are on the same network

### File Upload Issues
- Ensure the file is an MP3 format
- Check file size limits on your backend
- Verify the backend server is running and accessible

## Technologies Used

- React 18.2.0
- Axios for HTTP requests
- React Scripts for build tooling
- Modern CSS with gradients and animations

## Support

For issues or questions, please contact the Device Lab team at Games24x7.

## License

Internal use only - Games24x7 Device Lab
