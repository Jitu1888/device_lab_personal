import React, { useState, useEffect } from 'react';
import './App.css';
import AudioTestAPI from './services/audioTestAPI';

function App() {
  const [activeTab, setActiveTab] = useState('android'); // 'android' or 'ios'
  const [serverUrl, setServerUrl] = useState('http://localhost:8088/actuator-slave/appium');
  const [deviceUdid, setDeviceUdid] = useState('');
  const [devices, setDevices] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [statusType, setStatusType] = useState('info'); // info, success, error

  // Fetch devices on component mount
  useEffect(() => {
    loadDevices();
  }, []);

  // Load available devices
  const loadDevices = async () => {
    try {
      const result = await AudioTestAPI.getAllDevices();
      if (result.success && result.devices) {
        setDevices(result.devices);
        showStatus(`Loaded ${result.devices.length} devices`, 'success');
      } else {
        showStatus('Could not load devices. Please check server connection.', 'error');
      }
    } catch (error) {
      console.error('Error loading devices:', error);
      showStatus('Failed to load devices', 'error');
    }
  };

  // Update API base URL
  const updateServerUrl = () => {
    AudioTestAPI.setBaseURL(serverUrl);
    showStatus(`Server URL updated to: ${serverUrl}`, 'success');
    // Reload devices with new URL
    loadDevices();
  };

  // Show status message
  const showStatus = (message, type = 'info') => {
    setStatusMessage(message);
    setStatusType(type);
  };

  // Handle file selection
  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file) {
      // Check if it's an MP3 file
      if (!file.name.toLowerCase().endsWith('.mp3')) {
        showStatus('Please select an MP3 file', 'error');
        event.target.value = '';
        return;
      }

      setSelectedFile(file);
      showStatus(`Selected: ${file.name} (${(file.size / 1024).toFixed(2)} KB)`, 'success');
    }
  };

  // Upload audio file
  const uploadAudio = async () => {
    if (!selectedFile) {
      showStatus('Please select an audio file first', 'error');
      return;
    }

    setLoading(true);
    showStatus('Uploading audio file...', 'info');

    try {
      const result = await AudioTestAPI.uploadAudio(selectedFile);
      
      if (result.success) {
        showStatus(`✓ Audio file "${selectedFile.name}" uploaded successfully!`, 'success');
      } else {
        showStatus(`✗ Upload failed: ${result.message}`, 'error');
      }
    } catch (error) {
      showStatus(`✗ Upload error: ${error.message}`, 'error');
    } finally {
      setLoading(false);
    }
  };

  // Play audio on device
  const playAudio = async () => {
    if (!deviceUdid.trim()) {
      showStatus('Please enter a device UDID', 'error');
      return;
    }

    if (!selectedFile) {
      showStatus('Please select an audio file first', 'error');
      return;
    }

    setLoading(true);
    showStatus('Playing audio on device...', 'info');

    try {
      const result = await AudioTestAPI.playAudio(deviceUdid.trim(), selectedFile.name);
      
      if (result.success) {
        showStatus(`✓ Audio is now playing on device ${deviceUdid}`, 'success');
      } else {
        showStatus(`✗ Play failed: ${result.message}`, 'error');
      }
    } catch (error) {
      showStatus(`✗ Play error: ${error.message}`, 'error');
    } finally {
      setLoading(false);
    }
  };

  // Stop audio on device
  const stopAudio = async () => {
    if (!deviceUdid.trim()) {
      showStatus('Please enter a device UDID', 'error');
      return;
    }

    setLoading(true);
    showStatus('Stopping audio...', 'info');

    try {
      const result = await AudioTestAPI.stopAudio(deviceUdid.trim());
      
      if (result.success) {
        showStatus(`✓ Audio playback stopped on device ${deviceUdid}`, 'success');
      } else {
        showStatus(`✗ Stop failed: ${result.message}`, 'error');
      }
    } catch (error) {
      showStatus(`✗ Stop error: ${error.message}`, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="App">
      <div className="container">
        {/* Header */}
        <header className="header">
          <h1 className="header-title">🎵 Audio Test App</h1>
          <p className="header-subtitle">Manual Testing Tool for Device Lab</p>
        </header>

        {/* Platform Tabs */}
        <div className="tabs-container">
          <button 
            className={`tab-button ${activeTab === 'android' ? 'active' : ''}`}
            onClick={() => setActiveTab('android')}
          >
            🤖 Android
          </button>
          <button 
            className={`tab-button ${activeTab === 'ios' ? 'active' : ''}`}
            onClick={() => setActiveTab('ios')}
          >
            🍎 iOS
          </button>
        </div>

        {/* Android Tab Content */}
        {activeTab === 'android' && (
          <>
        {/* Server Configuration */}
        <section className="section">
          <h2 className="section-title">Server Configuration</h2>
          <div className="form-group">
            <label htmlFor="serverUrl">Backend Server URL</label>
            <input
              type="text"
              id="serverUrl"
              className="input"
              placeholder="http://192.168.1.100:8080/appium"
              value={serverUrl}
              onChange={(e) => setServerUrl(e.target.value)}
            />
          </div>
          <button 
            className="btn btn-secondary" 
            onClick={updateServerUrl}
            disabled={loading}
          >
            Update Server URL
          </button>
        </section>

        {/* Device UDID */}
        <section className="section">
          <h2 className="section-title">Device Configuration</h2>
          <div className="form-group">
            <label htmlFor="deviceUdid">Device UDID</label>
            <select
              id="deviceUdid"
              className="input"
              value={deviceUdid}
              onChange={(e) => setDeviceUdid(e.target.value)}
              disabled={loading}
            >
              <option value="">-- Select a device --</option>
              {devices.map((device) => (
                <option key={device.udid} value={device.udid}>
                  {device.udid} {device.deviceInformation?.model ? `(${device.deviceInformation.model})` : ''}
                </option>
              ))}
            </select>
          </div>
          <button 
            className="btn btn-secondary btn-small" 
            onClick={loadDevices}
            disabled={loading}
          >
            🔄 Refresh Devices
          </button>
          {devices.length === 0 && (
            <div className="info-message">
              <small>No devices found. Please check server connection.</small>
            </div>
          )}
          {devices.length > 0 && (
            <div className="info-message success">
              <small>✓ Found {devices.length} available device(s)</small>
            </div>
          )}
        </section>

        {/* File Selection */}
        <section className="section">
          <h2 className="section-title">Audio File Selection</h2>
          <div className="file-input-wrapper">
            <label htmlFor="audioFile" className="btn btn-secondary file-label">
              📁 {selectedFile ? 'Change MP3 File' : 'Select MP3 File'}
            </label>
            <input
              type="file"
              id="audioFile"
              accept=".mp3,audio/mpeg"
              onChange={handleFileSelect}
              disabled={loading}
              style={{ display: 'none' }}
            />
          </div>
          
          {selectedFile && (
            <div className="file-info">
              <div className="file-info-text">
                ✓ <strong>{selectedFile.name}</strong>
              </div>
              <div className="file-info-subtext">
                Size: {(selectedFile.size / 1024).toFixed(2)} KB
              </div>
            </div>
          )}
        </section>

        {/* Actions */}
        <section className="section">
          <h2 className="section-title">Actions</h2>
          
          <button 
            className="btn btn-upload" 
            onClick={uploadAudio}
            disabled={loading || !selectedFile}
          >
            ⬆️ Upload to Server
          </button>

          <button 
            className="btn btn-play" 
            onClick={playAudio}
            disabled={loading || !selectedFile || !deviceUdid.trim()}
          >
            ▶️ Play on Device
          </button>

          <button 
            className="btn btn-stop" 
            onClick={stopAudio}
            disabled={loading || !deviceUdid.trim()}
          >
            ⏹️ Stop Playback
          </button>
        </section>

        {/* Loading Indicator */}
        {loading && (
          <div className="loading-container">
            <div className="spinner"></div>
            <p>Processing...</p>
          </div>
        )}

        {/* Status Message */}
        {statusMessage && (
          <div className={`status-container status-${statusType}`}>
            <strong>Status:</strong> {statusMessage}
          </div>
        )}

        {/* Instructions */}
        <section className="instructions">
          <h3 className="instructions-title">📋 How to Use:</h3>
          <ol className="instructions-list">
            <li>Update the server URL if your backend is not on localhost</li>
            <li>Select a device from the dropdown (devices are loaded automatically)</li>
            <li>Select an MP3 audio file from your computer</li>
            <li>Click "Upload to Server" to upload the file</li>
            <li>Click "Play on Device" to play the audio on the specified device</li>
            <li>Click "Stop Playback" when you want to stop the audio</li>
          </ol>
        </section>

        {/* Footer */}
        <footer className="footer">
          <p>Made for Suki.ai Device Lab Testing</p>
        </footer>
          </>
        )}

        {/* iOS Tab Content */}
        {activeTab === 'ios' && (
          <section className="section coming-soon">
            <div className="coming-soon-content">
              <h2 className="coming-soon-title">🍎 iOS Audio Testing</h2>
              <p className="coming-soon-text">
                iOS audio testing functionality will be implemented soon.
              </p>
              <div className="coming-soon-features">
                <h3>Planned Features:</h3>
                <ul>
                  <li>Upload audio files for iOS devices</li>
                  <li>Play audio on iOS devices via simctl/idevice tools</li>
                  <li>Stop audio playback</li>
                  <li>iOS device selection</li>
                </ul>
              </div>
              <p className="coming-soon-note">
                💡 <strong>Note:</strong> This feature is under development
              </p>
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

export default App;
