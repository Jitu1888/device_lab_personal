import axios from 'axios';

// Default backend URL - can be changed from the UI
let API_BASE_URL = 'http://localhost:8088/actuator-slave/appium';

class AudioTestAPI {
  /**
   * Set the backend URL
   * @param {string} url - The backend URL
   */
  setBaseURL(url) {
    API_BASE_URL = url;
  }

  /**
   * Get current base URL
   * @returns {string} Current base URL
   */
  getBaseURL() {
    return API_BASE_URL;
  }

  /**
   * Upload audio file to the server
   * @param {File} audioFile - The audio file object
   * @returns {Promise} Response from the server
   */
  async uploadAudio(audioFile) {
    try {
      const formData = new FormData();
      formData.append('file', audioFile);

      const response = await axios.post(`${API_BASE_URL}/uploadAudio`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        timeout: 60000, // 60 seconds timeout
      });

      return {
        success: true,
        message: response.data,
      };
    } catch (error) {
      console.error('Upload Audio Error:', error);
      return {
        success: false,
        message: error.response?.data || error.message || 'Failed to upload audio',
      };
    }
  }

  /**
   * Play audio on a specific device
   * @param {string} udid - Device UDID
   * @param {string} audioName - Name of the audio file to play
   * @returns {Promise} Response from the server
   */
  async playAudio(udid, audioName) {
    try {
      const response = await axios.post(
        `${API_BASE_URL}/playAudio/${udid}`,
        { audioName },
        {
          headers: {
            'Content-Type': 'application/json',
          },
          timeout: 30000,
        }
      );

      return {
        success: true,
        message: response.data,
      };
    } catch (error) {
      console.error('Play Audio Error:', error);
      return {
        success: false,
        message: error.response?.data || error.message || 'Failed to play audio',
      };
    }
  }

  /**
   * Stop audio playback on a specific device
   * @param {string} udid - Device UDID
   * @returns {Promise} Response from the server
   */
  async stopAudio(udid) {
    try {
      const response = await axios.post(
        `${API_BASE_URL}/stopAudio/${udid}`,
        {},
        {
          headers: {
            'Content-Type': 'application/json',
          },
          timeout: 10000,
        }
      );

      return {
        success: true,
        message: response.data,
      };
    } catch (error) {
      console.error('Stop Audio Error:', error);
      return {
        success: false,
        message: error.response?.data || error.message || 'Failed to stop audio',
      };
    }
  }

  /**
   * Get all available devices
   * @returns {Promise} List of devices
   */
  async getAllDevices() {
    try {
      // Remove /appium from base URL for this endpoint as it's directly under root
      const baseUrl = API_BASE_URL.replace('/appium', '');
      const response = await axios.get(
        `${baseUrl}/findAllDevices`,
        {
          timeout: 10000,
        }
      );

      return {
        success: true,
        devices: response.data,
      };
    } catch (error) {
      console.error('Get All Devices Error:', error);
      return {
        success: false,
        devices: [],
        message: error.response?.data || error.message || 'Failed to fetch devices',
      };
    }
  }
}

export default new AudioTestAPI();
